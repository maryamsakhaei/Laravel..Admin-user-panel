<?php
        
/*  
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
/*----------------------------------register//login----------------------------------------*/
Route::get('create','Usercontroller@create');
Route::post('store','Usercontroller@store');
Route::get('show','Usercontroller@show');
/*login part*/
Route::get('login','Usercontroller@login');
Route::get('checklogin','Usercontroller@checklogin');   
Route::get('edit','Usercontroller@edit');
Route::post('update','Usercontroller@update');
/*----------------------------------index----------------------------------------*/
Route::get('','Sitecontroller@index');
Route::get('food','Sitecontroller@food');
Route::get('clothes','Sitecontroller@clothes');
Route::get('applience','Sitecontroller@applience');
Route::get('tools','Sitecontroller@tools');
Route::get('detail/{id}','Sitecontroller@detail');  
Route::get('cart','Sitecontroller@cart');
Route::post('addtocart','Sitecontroller@addtocart');
Route::get('checkout','Sitecontroller@checkout');
Route::post('track','Sitecontroller@track');
/*----------------------------------bank----------------------------------------*/
Route::get('purchase','Purchasecontroller@purchase');
/*----------------------------------Admin ------------------------------------*/
Route::get('adminlogin','Admincontroller@adminlogin');
Route::post('check','Admincontroller@check');
/*----------------------------------Admin profile ------------------------------------*/
Route::get('admin','Adminprofilecontroller@adminprofile');
Route::get('viewuser','Adminprofilecontroller@viewuser');   
Route::get('viewproduct','Adminprofilecontroller@viewproduct');
Route::get('insertproduct', 'Adminprofilecontroller@insert_product');
Route::post('insert_product_store', 'Adminprofilecontroller@insert_product_store');
Route::get('removeuser/{id}', 'Adminprofilecontroller@removeuser'); 
Route::get('bannuser/{id}', 'Adminprofilecontroller@bannuser');
Route::get('adminasuser/{id}','Adminprofilecontroller@adminasuser');
/*----------------------------------Category ------------------------------------*/
Route::post('categorystore', 'CategoryController@categorystore');

?>