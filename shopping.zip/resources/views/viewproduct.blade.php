@extends('master/layout')
@section('title')
    Shop
@endsection
@section('content')
<body style="background-color:black;">
<div class="container">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body p-0">
                    <div class="row p-5">
                        <div class="col-md-6">
                            <h2>Product catalog</h>
                        </div>
                    </div>
                    <hr class="my-5">
                    <div class="row p-5">
                        <div class="col-md-2"></div>
                        <div class="col-md-8">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th class="border-0 text-uppercase small font-weight-bold">ID</th>
                                        <th class="border-0 text-uppercase small font-weight-bold">Item</th>
                                        <th class="border-0 text-uppercase small font-weight-bold">Description</th>
                                        <th class="border-0 text-uppercase small font-weight-bold"></th>
                                        <th class="border-0 text-uppercase small font-weight-bold">Unit Cost</th>
                                        <th class="border-0 text-uppercase small font-weight-bold"></th>
                                    </tr>
                                </thead>
                                @foreach($product as $product)
                                <tbody>
                                    <tr>
                                        <td>{{ $product -> id}}</td>
                                        <td class="tdcolor">{{ $product -> name}}</td>
                                        <td>{{ $product -> description}}</td>
                                        <td class="tdcolor"></td>
                                        <td>{{ $product -> price}} Euro</td>
                                        <td class="tdcolor"></td>
                                    </tr>
                                </tbody>
                                @endforeach
                            </table>
                        </div>
                        <div class="col-md-2"></div>
                    </div>
                </div>
                <a href= "{{url('admin')}}" class="back">Back</a>
            </div>
        </div>
    </div>
</div>
@endsection
