@extends('master/layout')
@section('title')
    Shop
@endsection
@section('content')
<body style="background-color:black;">
<div class="container">
  <div class="row">
    <div class="col-md-3"></div>
    <div class="col-md-6">
          <h4>Manage User</h4>
          <table>
            <tr>
              <th>First Name</th>
              <th>&nbsp;&nbsp;&nbsp;</th>
              <th>&nbsp;&nbsp;&nbsp;</th>
              <th>Last Name</th>
              <th>&nbsp;&nbsp;&nbsp;</th>
              <th>&nbsp;&nbsp;&nbsp;</th>
              <th>Points</th>
              <th>&nbsp;&nbsp;&nbsp;&nbsp;</th>
            </tr>
            @foreach($userlist as $userlist)
            <tr>
              <td>{{$userlist-> name}}</td>
              <th>&nbsp;&nbsp;&nbsp;</th>
              <th>&nbsp;&nbsp;&nbsp;</th>
              <td>{{$userlist-> email}}</td>
              <th>&nbsp;&nbsp;&nbsp;</th>
              <th>&nbsp;&nbsp;&nbsp;</th>
              <td> <button class="bann" onclick="bannuser('{{$userlist->id}}')"><i class="fa fa-ban" aria-hidden="true"></i></button></td>
            </tr>
            @endforeach
          </table>
    </div>
    <div class="col-md-3"></div>
  </div>
</div>
<script>
function bannuser(id){
        $.ajaxSetup({
            headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
        });
        jQuery.ajax({
            url: '{{ url('') }}/bannuser',
            type: 'post',
            data: 'id='+id,
            success: function(response)
            {
              alert(response);
              alert('Blocked');
                //alert(response);

                // if(response==1){

                // }
                // else{
                //     alert( 'کد وارد شد صحیح نمی باشد');
                // }
            },
            error: function(){
                alert('Try again');
            }

        });
    }

</script>
@endsection

