@extends('master/layout')
@section('Shopping')@endsection
@section('content')
<div class="container">
    <div class="row">
        <table>
            <tr>
              <th>id</th>
              <th>name</th>
            </tr>
            <tr>
              <td>{{ Session::get('id') }}</td>
              <td>{{ Session::get('number') }}</td>
            </tr>
            
          </table>
  </div>    
</div><br><br>
<!--===================footer=====================================================-->
<div class="container-fluid grad1">
  <div class="row">
      <div class="col-md-4"></div>
      <div class="col-md-4">
        <p class="foot-text">Fallow Us</p>
        <p class="foot-vs">Fallow Us</p>
          <div class="social">
            <a href="#" class="fa fa-twitter"></a>
            <a href="#" class="fa fa-instagram"></a>
            <a href="#" class="fa fa-facebook"></a>
        </div><!-- social -->
      </div>
      <div class="col-md-4"></div>
  </div>
</div>
@endsection

