@extends('master/layout')
@section('Shopping')@endsection
@section('content')
<body>
    <div class="container-fluid register-bg">
         <div class="row">
            <div class="col-md-2"></div>
            <div class="col-md-4">
                 <p class="profile">Wellcome {{ $name->name }}</p>
            </div>
            <div class="col-md-4"></div>
            <div class="col-md-2"></div>
        </div> 
        <br>
    <!--===================================photo===================-->
    <div class="row">
            <div class="col-md-2"></div>
            <div class="col-md-4">
                <!-- <img src="{{url('resources/assets/image/photo.jpg')}}" class="profile-photo"> -->
            </div>
            <div class="col-md-4">
                <form action="update" method="post">
                    @csrf
                    <div class="container">
                        <input type="text" value="{{ $name->name }}" name="name"  class="inputss" disabled><br>
                        <input type="text" value="{{ $name->email }}" name="email" class="inputss" disabled><br>
                        <input type="number" value="{{ $name->password }}" name="password"class="inputss" disabled>
                        <br>
                        <input type="number" value="{{ $name->mobile }}" name="mobile" class="inputss" disabled>
                        <br>  <br>  <br>
                        <button type="submit" class="buttons" disabled>Send</button>
                </form>
            </div>
            
            <div class="col-md-2"></div>
        </div>
    </div><!--container-->
@endsection
