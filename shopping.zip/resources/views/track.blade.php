@extends('master/layout')
@section('Shopping')@endsection
@section('content')
<body style="background-color:black;">   
    <!-- start- navigation-->
    <div class="main-gray-box">
        <div class="bs-example" data-example-id="inverted-navbar">
            <nav class="navbar navbar-inverse ">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <button type="button" class="collapsed navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-9" aria-expanded="false"> <span class="sr-only">Toggle navigation</span>  <span class="icon-bar"></span>  <span class="icon-bar"></span>  <span class="icon-bar"></span>
                        </button> <a href="#" class="navbar-brand"><img class="icon-apple" src="{{url('resources/assets/image/logo.PNG')}}"></a>
                    </div>
                    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-9">
                        <ul class="nav navbar-nav space">
                            <li><a href="# " class="li-mg">&nbsp;&nbsp;&nbsp;&nbsp; </a>
                            </li>
                            <li><a href="# " class="li-mg">&nbsp;&nbsp;&nbsp;&nbsp; </a>
                            </li>
                            <li><a href="# " class="li-mg">&nbsp;&nbsp;&nbsp;&nbsp; </a>
                            </li>
                            <li class="li-mg"><a href="#">Home</a>
                            </li>
                            <li class="li-mg"><a href="#">shop</a>
                            </li>
                            <li><a href="# " class="li-mg">about us</a>
                            </li>
                            <li><a href="# " class="li-mg">&nbsp;&nbsp;&nbsp;&nbsp;</a>
                            </li>
                            <li><a href="# " class="li-mg">&nbsp;&nbsp;&nbsp;&nbsp; </a>
                            </li>
                        </ul>
                        <!--logo-->
                        <!-- <i class="fas fa-user"></i> 
                        <i class="far fa-user"></i> 
                        <i class="fas fa-car"></i> 
                        <i class="fab fa-instagram"></i> -->
                         <!--logo-->
                        <div class="search">
                            <img class="search " src="{{url('resources/assets/image/search1.png')}}">
                        </div>
                    </div>
                </div>
            </nav>
        </div>
        <br><br>
    <!--===================track photo=====================================================-->
    <div class="container">
      <div class="row">
        <div class="col-md-1"></div>
        <div class="col-md-10">
        <div class="row shop-tracking-status">
    <div class="col-md-12">
            <h4>Your track number:</h4>
            <div class="order-status">

                <div class="order-status-timeline">
                    <!-- class names: c0 c1 c2 c3 and c4 -->
                    <div class="order-status-timeline-completion c3"></div>
                </div>

                <div class="image-order-status image-order-status-new active img-circle">
                    <span class="status">Accepted</span>
                    <div class="icon"></div>
                </div>
                <div class="image-order-status image-order-status-active active img-circle">
                    <span class="status">In progress</span>
                    <div class="icon"></div>
                </div>
                <div class="image-order-status image-order-status-intransit active img-circle">
                    <span class="status">Shipped</span>
                    <div class="icon"></div>
                </div>
                <div class="image-order-status image-order-status-delivered active img-circle">
                    <span class="status">Delivered</span>
                    <div class="icon"></div>
                </div>
                <div class="image-order-status image-order-status-completed active img-circle">
                    <span class="status">Completed</span>
                    <div class="icon"></div>
                </div>

            </div>
        </div>
    </div>

</div>
        </div>
        <div class="col-md-1"></div>
      </div>
    </div>
    <!--===================footer=====================================================-->
    <br><br><br>
    <img src="{{url('resources/assets/image/icon.PNG')}}" class="icon-l">
    <p class="goodlife">Good Life With Us</p>
    <img src="{{url('resources/assets/image/icon.PNG')}}" class="icon-r">
    <br><br><br>

@endsection
