@include('master/header')
@yield('index')
@include('master/footer')