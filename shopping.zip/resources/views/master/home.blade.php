@extends('master/layout')
@section('tittle')
@endsection
@section('content')

@endsection
