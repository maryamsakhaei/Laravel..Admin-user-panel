@extends('master/layout')
@section('title')
    comment
@endsection
@section('content')
<body style="background-color:black;">
<div class="container">
      <!-- Breadcrumb -->
      <nav aria-label="breadcrumb" class="main-breadcrumb">
        <ol class="breadcrumb">
          <p class="user-info">User Information</p>
        </ol>
      </nav>
      <!-- /Breadcrumb -->
      <div class="col-md-12">
      @foreach($name as $model)
     <div class="col-md-4">
     <div class="col mb-3"> 
          <div class="carduser">
            <img src="{{url('resources/assets/image/rectangle-border.jpg')}}" alt="Cover" class="card-img-top">
            <div class="card-body text-center">
              <img src="{{url('resources/assets/image/user1.png')}}" style="width:100px;margin-top:-149px" alt="User" class="img-fluid img-thumbnail rounded-circle border-0 mb-3">
              <h5 class="card-title">{{ $model -> name}}</h5>
              <p class="text-secondary mb-1">{{ $model -> email}}</p>
              <p class="text-muted font-size-sm">{{ $model -> mobile}}</p>
            </div>
            <div class="card-footer">
              <!-- <form action="bannuser" method="post">
              @csrf
                  <input type="hidden" name="id" value="{{$model -> id}}">
                  <button type="submit" class="btn btn-light " type="button" name="Block"><i class="material-icons">Block</i>User</button>
              </form>
              <form action="removeuser" method="post">
              @csrf
                <input type="hidden" name="id" value="{{$model -> id}}">
              
                   <button type="submit" class="btn btn-light " type="button" name="Remove"><i class="material-icons">Remove</i>User</button>
              </form> -->
              <a href="{{url('removeuser/').'/'. $model->id}}" class="r-user">Remove user</a>
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              <a href="{{url('bannuser').'/'. $model->id}}" class="r-user">Ban user</a>
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              <a href="{{url('adminasuser').'/'. $model->id}}" class="r-user">As user login</a>
            </div>
          </div>
        </div>
        </div>
        @endforeach
     <div class="col-md-4"></div>
     <div class="col-md-4"></div>
    </div>
    <a href= "{{url('admin')}}" class="back">Back</a>
    <br><br><br>
    @endsection
